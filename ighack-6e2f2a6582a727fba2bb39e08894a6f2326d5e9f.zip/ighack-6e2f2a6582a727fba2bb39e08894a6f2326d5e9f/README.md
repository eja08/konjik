<h1 align="center">IG-HACK v1.0</h1>
<p align="center">
      A new automated script for Instagram Account hackig from bruteforce
</p>

## 🔍 ***About IG-HACK***:

ighack is a bash based script which is officially made to test password strength of instagram account from termux with bruteforce attack and. This tool works on both rooted Android device and Non-rooted Android device.

[![Build Status](https://img.shields.io/github/stars/noob-hackers/ighack.svg)](https://github.com/noob-hackers/ighack)
[![Build Status](https://img.shields.io/github/forks/noob-hackers/ighack.svg)](https://github.com/noob-hackers/ighack)
[![License: MIT](https://img.shields.io/github/license/noob-hackers/ighack.svg)](https://github.com/noob-hackers/ighack)
[![Rawsec's CyberSecurity Inventory](https://inventory.rawsec.ml/img/badges/Rawsec-inventoried-FF5050_flat.svg)](https://inventory.rawsec.ml/tools.html#ighack)
[![Stage](https://img.shields.io/badge/Release-Stable-brightgreen.svg)]()
[![Awesome](https://awesome.re/badge.svg)](https://awesome.re)

![Screenshot_2020-06-22-18-53-12-214_com termux](https://user-images.githubusercontent.com/49580304/85358677-f8c66d00-b531-11ea-8f38-c9e298551a9c.jpg)


### 📌 ***IG-HACK is available for***:

* Termux

### 📌 ***Installation and usage guide***:
```
$ apt-get update -y
```
```
$ apt-get upgrade -y
```
```
$ pkg install python -y 
```
```
$ pkg install python2 -y
```
```
$ pkg install git -y
```
```
$ pip install lolcat
```
```
$ git clone https://github.com/noob-hackers/ighack
```
```
$ ls
```
```
$ cd ighack
```
```
$ ls
```
```
$ bash setup
```
```
$ bash ighack.sh
```
* Now you need internet connection to continue further process...

* You can select any option by clicking on your keyboard

* Note:- Don't delete any of the scripts included in core files

* Open new session and start TOR (tor) before starting the attack

## 📌 ***Screenshot*** :
![Screenshot_2020-06-22-22-03-35-080_com termux](https://user-images.githubusercontent.com/49580304/85359279-6b841800-b533-11ea-8e27-1e7c3bfc882e.jpg)

## 📌 ***Full video tutorial***:

## 🔗 ***Check this***

### Subscribe our channel on youtube:
https://www.youtube.com/noobhackers

### Chekout our webite:
https://www.noob-hackers.com

## 👥 ***Join***

### Facebook group: 
https://www.facebook.com/groups/1936478173310085

### Telegram channel:
https://t.me/noobhack

### Facebook page:
https://www.facebook.com/Noob-Hackers-250938565573643

### Instagram: 
https://www.instagram.com/noobhackers352

### Pinterest:
https://in.pinterest.com/noobhackers

### My GitHub ID link:
https://www.github.com/noob-hackers

### 📢 Warning

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
